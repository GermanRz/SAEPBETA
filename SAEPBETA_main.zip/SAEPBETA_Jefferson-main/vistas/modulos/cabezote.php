<!-- Navbar -->
<nav class="main-header navbar navbar-expand navbar-white navbar-light">
  <!-- Left navbar links -->
  <ul class="navbar-nav">
    <!-- Aquí puedes poner enlaces si quieres -->
  </ul>
      <nav class="navbar navbar-expand navbar-light">
  <ul class="navbar-nav">
    
    <li class="nav-item">
      <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
    </li>
  </ul>
 </nav>
      <div>
        <h1 style="margin-left: 10px;">Bienvenido administrador del sistema</h1>
      </div>

  <!-- Right navbar links -->
  <ul class="navbar-nav ml-auto">
    <!-- Notifications Dropdown Menu -->
  

    <!-- User Dropdown -->
    <li class="nav-item dropdown user-menu">
      <a href="#" class="nav-link dropdown-toggle" data-toggle="dropdown">
        <img src="vistas/dist/img/user2-160x160.jpg" class="user-image img-circle elevation-2" alt="User Image" style="width: 45px; height: 45px; object-fit: cover;">
      </a>
      <ul class="dropdown-menu dropdown-menu-lg dropdown-menu-right">
        <!-- User image -->
        <li class="user-header bg-primary">
          <img src="vistas/dist/img/user2-160x160.jpg" class="img-circle elevation-2" alt="User Image">
          <p>
            Administrador del sistema
            <small>Miembro desde Noviembre 2025</small>
          </p>
        </li>
        <!-- Menu Footer-->
        <li class="user-footer">
          <a href="#" class="btn btn-default btn-flat">Perfil</a>
          <a href="salir" class="btn btn-default btn-flat float-right">Cerrar sesión</a>
        </li>
      </ul>
    </li>
  </ul>
</nav>

