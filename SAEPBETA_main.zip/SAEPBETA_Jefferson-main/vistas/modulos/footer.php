<footer class="main-footer">
    <div class="float-right d-none d-sm-block">
        <b>Version</b> 0.0.1
    </div>
    <strong>Copyright &copy; 2025 <a href="#">Seguimiento aprendices en etapa productiva 2823094</a>.</strong> All rights reserved.
</footer>